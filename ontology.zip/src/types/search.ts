export interface SearchResult {
  sujeto: string
  predicado: string
  objeto: string
}
